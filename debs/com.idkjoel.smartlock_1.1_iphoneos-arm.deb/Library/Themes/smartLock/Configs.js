var vertical_spacing = 200;
var notification_spacing = 55;
var xhour = true; // Enable for 12h clock. Disable for 24h.
var green = true; // Activate for green battery charging indicator.